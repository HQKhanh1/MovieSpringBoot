create table detailMovie (
	id int identity(1,1) primary key,
	title varchar(500) not null,
	poster varchar(500) not null,
	details varchar(2000) not null,
	movie_status bit not null,
	link_trailer varchar(500),
	link_movie varchar(500) not null,
	release_date date not null,
	time_movie time not null,
	view_num int
)
