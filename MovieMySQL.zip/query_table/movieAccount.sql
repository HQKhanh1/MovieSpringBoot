create table movie_account(
	movie_acc_id int primary key identity,
	acc_name char(30) not null,
	acc_password varchar(255) not null,
	enabled bit default(0),
	email varchar(255) not null,
	avatar varchar(255),
	lastname varchar(255) not null,
	firstname varchar(255) not null,
	birthday date not null,
	id_commune_ward_town int,
	address_detail varchar(1000),
	phone_number char(13),
	gender bit not null,
	constraint unique_email unique(email),
	constraint unique_username unique(acc_name)
)
