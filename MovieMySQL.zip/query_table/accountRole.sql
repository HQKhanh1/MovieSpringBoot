create table account_role (
	id int identity(1,1) primary key,
	name varchar(64) not null
)