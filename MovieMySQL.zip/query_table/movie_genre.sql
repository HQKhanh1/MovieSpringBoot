create table movie_genre (
	id int identity(1,1) primary key,
	name varchar(255) not null
)