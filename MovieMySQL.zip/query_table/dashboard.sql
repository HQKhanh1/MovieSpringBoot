create table dashboard(
	id int primary key,
	name nvarchar(255) not null unique
)