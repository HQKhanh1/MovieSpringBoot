create table movie_cast(
	id int identity(1,1) primary key,
	avatar varchar(255) not null,
	name varchar(255) not null,
	story varchar(1000)
)