create table token (
	id int identity(1,1) primary key,
	id_user int not null,
	create_time datetime not null,
	token_content varchar(255) not null
)