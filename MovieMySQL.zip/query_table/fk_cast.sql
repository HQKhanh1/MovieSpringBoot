create table fk_cast(
	movie_id int not null,
	cast_id int not null
)

go
ALTER TABLE fk_cast
ADD CONSTRAINT fk_cast_pk PRIMARY KEY (movie_id, cast_id);