create table movie_driector(
	id int identity(1,1) primary key,
	avatar varchar(255) not null,
	name varchar(500) not null,
	story varchar(1000) not null
)