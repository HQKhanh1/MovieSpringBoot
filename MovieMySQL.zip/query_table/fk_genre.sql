create table fk_genre(
	movie_id int not null,
	genre_id int not null
)
go
ALTER TABLE fk_genre
ADD CONSTRAINT fk_genre_pk PRIMARY KEY (movie_id, genre_id);