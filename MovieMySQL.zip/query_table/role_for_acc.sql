create table role_for_account (
	id_role int not null,
	id_acc int not null
	PRIMARY KEY (id_role, id_acc)
);
