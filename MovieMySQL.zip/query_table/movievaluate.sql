create table move_evaluate(
	idUser int not null,
	idMovie int not null,
	evaluate_Time date not null,
	evaluate_content nvarchar(4000),
	evaluate_rate int not null
)
go
ALTER TABLE move_evaluate
ADD CONSTRAINT move_evaluate_pk PRIMARY KEY (idUser, idMovie);
