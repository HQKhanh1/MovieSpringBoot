create table fk_driector(
	movie_id int not null,
	dricetor_id int not null
)

go
ALTER TABLE fk_driector
ADD CONSTRAINT fk_driector_pk PRIMARY KEY (movie_id, dricetor_id);